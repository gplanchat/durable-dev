# Modèle distribué et re-dispatch des workflows

ADR009-distributed-workflow-dispatch
===

Introduction
---

Ce **Architecture Decision Record** définit le modèle d'exécution distribué pour les workflows du projet Durable, où le workflow et les activités s'exécutent dans des process séparés. Il complète [ADR007 - Reprise et recovery](ADR007-workflow-recovery.md) en détaillant l'implémentation du re-dispatch.

Contexte
---

En mode **inline** (Option B de ADR007), le workflow et les activités s'exécutent dans le même process via `drainActivityQueueOnce`. Pour la scalabilité horizontale, il faut un mode **distribué** où :
- Les activités sont exécutées par des workers dédiés
- Le workflow peut "sortir" après avoir schedulé une activité
- Le workflow est re-dispatché lorsque l'activité se termine

Principe du re-dispatch
---

1. **Démarrage** : Un message `WorkflowRunMessage` est dispatché avec `executionId`, `workflowType`, `payload`
2. **Exécution** : Le handler démarre le workflow. Au premier `activity()`, l'activité est enqueueée et le handler **retourne** (exit)
3. **Activité** : Un worker consomme le message d'activité, l'exécute, append `ActivityCompleted` à l'EventStore
4. **Re-dispatch** : Le worker dispatch un nouveau `WorkflowRunMessage(executionId)` sur le transport dédié
5. **Reprise** : Le handler workflow reçoit le message, rejoue depuis l'EventStore, récupère le résultat du slot, continue jusqu'au prochain `activity()` ou à la fin

### Continue-as-new

Si le workflow appelle `ExecutionContext::continueAsNew($workflowType, $payload)`, le moteur append `WorkflowContinuedAsNew` sur le run courant (sans `ExecutionCompleted`) et lève `ContinueAsNewRequested`. Le `WorkflowRunHandler` supprime les métadonnées de l’ancien `executionId`, en enregistre pour un **nouvel** identifiant, et dispatche un `WorkflowRunMessage` de démarrage (`dispatchNewWorkflowRun`) avec le type et le payload du run suivant.

Prérequis
---

- **WorkflowRegistry** : enregistre les workflows par type (string → factory du handler)
- **WorkflowMetadataStore** : persiste (executionId, workflowType, payload) au démarrage pour la reprise
- **WorkflowResumeDispatcher** : interface pour dispatcher la reprise (injectée dans le worker d'activités)

Transports
---

- **Activités** : transport existant (`durable_activities`) — messages `ActivityMessage`
- **Workflows** : transport dédié (`durable_workflows`) — messages `WorkflowRunMessage`
- **Timers (réveil)** : message `FireWorkflowTimersMessage` — à router (ex. sync / cron) vers `FireWorkflowTimersHandler` ; append `TimerCompleted` + `dispatchResume` si au moins un timer est devenu dû
- **Reprises** : `MessengerWorkflowResumeDispatcher` utilise `DispatchAfterCurrentBusStamp` pour ne pas empiler des `WorkflowRunMessage` en récursion synchrone pendant le handler courant

Configuration
---

```yaml
durable:
  distributed: true  # Active le re-dispatch
  workflow_transport: durable_workflows
```

Lorsque `distributed: false` (défaut), le comportement reste le mode inline actuel.

Concurrence `any()` / `race()`
---

Lorsqu’une compétition d’activités se termine (premier `Awaitable` réussi ou rejeté), les activités **encore en file** et **non consommées** sont **retirées du transport** (best effort) : `ActivityTransportInterface::removePendingFor()`. Un événement **`ActivityCancelled`** est append avec la raison `race_superseded`, et le slot correspondant rejoue une **`ActivitySupersededException`**.

- **In-memory / DBAL** : retrait effectif du message en attente.
- **Messenger** : pas de retrait fiable sans API dédiée — retour `false`, l’activité peut encore s’exécuter (comportement acceptable).
- Si le worker a **déjà vidé toute la file** avant la reprise du workflow, les activités perdantes peuvent déjà être **`ActivityCompleted`** : aucune annulation n’est alors possible, l’historique reste cohérent.

Suspension signal / update vs activité / timer
---

`WorkflowSuspendedException` porte **`shouldDispatchResume()`** : en mode distribué, une attente **activité** ou **timer** (`ActivityAwaitable`, `TimerAwaitable`, y compris dans `any()` / `CancellingAnyAwaitable`) provoque un `dispatchResume` depuis `WorkflowRunHandler` (worker activité ou horloge peut faire progresser le run). Une attente **signal** ou **update** ne déclenche **pas** ce re-dispatch automatique : sinon, avec un transport Messenger **sync**, la reprise récursive bouclerait sans fin. La reprise est alors assurée par **`DeliverWorkflowSignalMessage`** / **`DeliverWorkflowUpdateMessage`** (append journal + `dispatchResume`).

Limitations connues
---

- Les **timers** (`delay`) en mode distribué nécessitent qu’un process appelle périodiquement la reprise (ou un mécanisme de réveil dédié) pour que `checkTimers` puisse append `TimerCompleted` avant le prochain `WorkflowRunMessage`
- Le handler du workflow doit être **reproductible** : pas de closure capturant des références non sérialisables

Références
---

- [ADR007 - Reprise et recovery](ADR007-workflow-recovery.md)
- [ADR005 - Intégration Messenger](ADR005-messenger-integration.md)
- [Durable Workflow - How it works](https://durable-workflow.com/docs/how-it-works)
