# Intégration Symfony Messenger

ADR005-messenger-integration
===

Introduction
---

Ce **Architecture Decision Record** décide d'utiliser **Symfony Messenger** comme transport pour les activités du projet Durable. Cette décision permet une exécution distribuée des activités sans dépendance à RoadRunner, en s'appuyant sur l'écosystème Symfony existant.

Contexte
---

Le projet Durable doit permettre l'exécution d'activités de manière asynchrone et distribuée. Les alternatives considérées incluaient :

- **RoadRunner + Temporal** : impose RoadRunner, complexité élevée
- **Laravel Queues** : non applicable (projet Symfony)
- **Symfony Messenger** : natif Symfony, support Redis, Dbal, SQS, etc.
- **Doctrine DBAL** : simple, sans dépendance externe (transport Dbal)

Décision
---

Symfony Messenger est utilisé comme **transport principal** pour les messages d'activité (`ActivityMessage`). Un transport Dbal et un transport InMemory sont également fournis pour les environnements de test et les déploiements légers.

Implémentation
---

### MessengerActivityTransport

Adapte l'interface `ActivityTransportInterface` aux primitives Messenger :

- `enqueue()` → `SenderInterface::send()`
- `dequeue()` → `ReceiverInterface::get()` puis `ack()`

### Configuration

```yaml
# config/packages/durable.php
durable:
  transport: messenger  # ou dbal, in_memory
  messenger:
    transport_name: durable_activities
```

### Worker

La commande `durable:activity:consume` consomme les messages depuis le transport configuré, exécute les activités via `ActivityExecutor`, et persiste les résultats dans l'EventStore.

Modèle distribué
---

- **Mode inline** : workflow et activités dans le même process (`drainActivityQueueOnce`)
- **Mode distribué** : activités exécutées par des workers (`durable:activity:consume`), EventStore partagé (Dbal)

Pour le mode distribué complet, le workflow devra être re-dispatché après chaque activité (modèle Durable Workflow / Laravel). Voir ADR007 pour la stratégie de reprise.

Références
---

- [Symfony Messenger](https://symfony.com/doc/current/messenger.html)
- [Durable Workflow - How it works](https://durable-workflow.com/docs/how-it-works)
- [ADR004 - Ports et Adapters](ADR004-ports-and-adapters.md)
- [ADR007 - Reprise et recovery](ADR007-workflow-recovery.md)
