# Stratégie de reprise et recovery des workflows

ADR007-workflow-recovery
===

Introduction
---

Ce **Architecture Decision Record** définit la stratégie de reprise des workflows du projet Durable lorsque l'exécution est interrompue ou échoue. Cette stratégie s'appuie sur l'event sourcing et le replay déterministe déjà implémentés.

Contexte
---

Les workflows durables doivent survivre aux :
- Crashes du process
- Redémarrages des workers
- Échecs temporaires des activités
- Timeouts et indisponibilités réseau

La reprise doit garantir la cohérence des données et l'absence de duplication des effets de bord (idempotence).

Stratégie actuelle : Event Sourcing et replay
---

### Principe

Le flux d'événements (`EventStore::readStream`) constitue le **checkpoint implicite** du workflow. À chaque reprise, le workflow est rejoué (replay) en lisant les événements dans l'ordre. Les résultats des activités déjà complétées sont récupérés depuis les événements `ActivityCompleted` / `ActivityFailed`, sans ré-exécution.

### Slots déterministes

Chaque appel à `$context->activity()`, `$context->delay()` / `$context->timer()` ou `$context->sideEffect()` est associé à un slot (index séquentiel par famille d’opérations). Lors du replay, `findReplayResultForSlot()` et `findReplayTimerForSlot()` déterminent si le slot a déjà un résultat enregistré. Pour les activités complétées avec un résultat **`null`**, le moteur utilise `array_key_exists` afin de ne pas confondre avec l’absence de complétion (voir [ADR010](ADR010-temporal-parity-events-and-replay.md)).

### Garanties

- **Déterminisme** : le code du workflow ne doit pas contenir d'I/O ou de sources non déterministes (random, date, etc.) **hors** des activités ou des **side effects** explicites
- **Side effects** : toute valeur non déterministe doit passer par `ExecutionContext::sideEffect()` (résultat journalisé, pas de ré-exécution au replay) — voir [ADR010](ADR010-temporal-parity-events-and-replay.md)
- **Idempotence** : les activités doivent être idempotentes

Mode distribué : re-dispatch du workflow
---

Pour un environnement distribué où le workflow et les activités s'exécutent dans des process séparés, la reprise nécessite que le **workflow soit re-dispatché** lorsqu'une activité se termine.

### Option A : Workflow comme job Messenger

1. Le workflow est un message Messenger (ex. `WorkflowRunMessage`)
2. Le consumer démarre le workflow, qui schedule une activité puis **exit**
3. L'activité est exécutée par un worker, qui append `ActivityCompleted` à l'EventStore
4. Un mécanisme (polling, trigger, ou callback) re-dispatch le workflow
5. Au replay, le workflow détecte que l'activité est complétée, récupère le résultat, continue

### Option B : Mode inline actuel

Workflow et activités dans le même process (drainActivityQueueOnce). Pas de re-dispatch nécessaire ; la reprise après crash implique de relancer le workflow depuis le début (le replay fera le travail).

Implémentation future
---

L'implémentation du re-dispatch (Option A) fera l'objet d'une évolution documentée. Les prérequis sont :
- Persistance de l'état "workflow en attente" (ex. table `workflow_pending`)
- Consommateur ou listener qui re-dispatch le workflow à la réception de `ActivityCompleted`
- Mécanisme de réveil pour les timers (table de timers ou cron)

Références
---

- [RUNTIME-RFC033 - Workflow Recovery](../../architecture/runtime/rfcs/RUNTIME-RFC033-workflow-recovery-and-resume-strategy.md)
- [ADR005 - Intégration Messenger](ADR005-messenger-integration.md)
- [PRD001 - État actuel](../prd/PRD001-current-component-state.md)
- [ADR010 - Parité Temporal, événements et replay](ADR010-temporal-parity-events-and-replay.md)
