# État actuel du composant Durable

PRD001-current-component-state
===

Introduction
---

Ce **Product Requirements Document** documente l'état actuel du composant et du Bundle Durable au moment de l'initialisation de la documentation. Il sert de référence pour la compréhension des capacités existantes et des axes d'évolution.

Objectifs
---

Fournir un composant PHP et un Bundle Symfony permettant des **exécutions durables** : workflows et activités inspirées de Temporal.io, sans dépendance à RoadRunner.

Spécifications fonctionnelles
---

### Workflows

- **Orchestration** : exécution d'un handler avec `ExecutionContext` et `ExecutionRuntime`
- **Activités** : `$context->activity($name, $payload)` retourne un `Awaitable`
- **Timers** : `$context->delay($seconds)` ou alias `$context->timer($seconds)` pour des délais relatifs durables (journal `TimerScheduled` / `TimerCompleted`)
- **Side effects** : `$context->sideEffect(fn (): mixed => …)` — résultat persisté dans `SideEffectRecorded`, pas de ré-exécution au replay ([ADR010](../adr/ADR010-temporal-parity-events-and-replay.md))
- **Workflows enfants** : `$context->executeChildWorkflow($type, $input, ?ChildWorkflowOptions)` — options `workflowId` + `parentClosePolicy` ; journal parent enrichi ; `ParentChildWorkflowCoordinator` à la fermeture du parent (`ExecutionEngine`) ; `WorkflowCancellationRequested` si *request cancel* ([ADR010](../adr/ADR010-temporal-parity-events-and-replay.md), [ADR009](../adr/ADR009-distributed-workflow-dispatch.md))
- **Continue-as-new** : `$context->continueAsNew($workflowType, $payload)` — `WorkflowContinuedAsNew` + exception `ContinueAsNewRequested` ; en mode distribué, `WorkflowRunHandler` enchaîne un nouveau `executionId` ([ADR009](../adr/ADR009-distributed-workflow-dispatch.md))
- **Signaux / updates** : `$context->waitSignal($name)`, `$context->waitUpdate($name)` — événements `WorkflowSignalReceived`, `WorkflowUpdateHandled` (ordre = slots) ; livraison asynchrone via Messenger : `DeliverWorkflowSignalMessage` / `DeliverWorkflowUpdateMessage` + handlers bundle (append + `WorkflowResumeDispatcher`) ; en mode distribué, `WorkflowRunHandler` **ne** re-dispatch pas automatiquement sur suspension signal/update (`WorkflowSuspendedException::shouldDispatchResume()`), pour éviter boucle infinie avec transport sync ; **queries** : `Query\WorkflowQueryEvaluator` + service `WorkflowQueryRunner` (lecture journal)
- **Parallélisme** : `parallel()`, `all()`, `any()`, `race()` via les fonctions globales
- **Replay** : reconstruction déterministe de l'état à partir du flux d'événements (slots)

### Event Store

- Interface `EventStoreInterface` : `append(Event)`, `readStream(executionId)`
- Événements : `ExecutionStarted`, `ActivityScheduled`, `ActivityCompleted`, `ActivityFailed`, `ActivityCancelled`, `ActivityCatastrophicFailure`, `TimerScheduled`, `TimerCompleted`, `SideEffectRecorded`, `ChildWorkflowScheduled`, `ChildWorkflowCompleted`, `ChildWorkflowFailed`, `WorkflowContinuedAsNew`, `WorkflowSignalReceived`, `WorkflowUpdateHandled`, `WorkflowCancellationRequested`, `WorkflowExecutionFailed`, `ExecutionCompleted`
- Implémentations : `DbalEventStore`, `InMemoryEventStore`

### Transport des activités

- Interface `ActivityTransportInterface` : `enqueue()`, `dequeue()`, `isEmpty()`
- Implémentations : `MessengerActivityTransport`, `DbalActivityTransport`, `InMemoryActivityTransport`

### Activités

- `ActivityExecutor` : exécution par nom + payload
- `RegistryActivityExecutor` : enregistrement de handlers par nom
- Retries configurés au niveau du worker

### Bundle Symfony

- `DurableBundle` : enregistrement des services et de la configuration (`ExecutionEngine` + `ParentChildWorkflowCoordinator`, handlers `DeliverWorkflowSignalHandler` / `DeliverWorkflowUpdateHandler` / `FireWorkflowTimersHandler`, `WorkflowQueryRunner`, lien parent↔enfant `ChildWorkflowParentLinkStoreInterface`)
- Commande `durable:activity:consume` : consommation des messages d'activité
- Configuration : transport, event store, max retries, `child_workflow.async_messenger` (avec `distributed: true`)
- Reprises workflow via `MessengerWorkflowResumeDispatcher` : `DispatchAfterCurrentBusStamp` pour éviter récursion synchrone du bus

Critères d'acceptation
---

- [x] Workflow avec activités et replay fonctionnel (tests unitaires et d'intégration)
- [x] Transport Messenger opérationnel
- [x] Transport Dbal opérationnel
- [x] Transport InMemory pour les tests
- [x] Timers (délai relatif) supportés
- [x] Side effects avec journal et replay ([ADR010](../adr/ADR010-temporal-parity-events-and-replay.md))
- [x] Workflows enfants (`executeChildWorkflow` + `ChildWorkflowRunner`, option async Messenger + journal parent mis à jour par `WorkflowRunHandler`)
- [x] Réveil timers distribués (`FireWorkflowTimersMessage` + handler)
- [x] Continue-as-new (événement + handler Messenger)
- [x] Signaux / updates (`waitSignal` / `waitUpdate`) + handlers Messenger + queries journal (`WorkflowQueryEvaluator` / `WorkflowQueryRunner`)
- [x] Parent close policy + id enfant explicite (`ChildWorkflowOptions`, coordinateur parent/enfant)
- [x] Gestion des échecs d'activités avec retries
- [x] Persistence des événements en base (DbalEventStore)

État d'implémentation
---

| Composant | État | Notes |
|-----------|------|-------|
| ExecutionEngine | Implémenté | Démarrage, handler, événements |
| ExecutionContext | Implémenté | Slots, replay, activités, timers, side effects, enfant, signaux, updates |
| ChildWorkflowRunner | Implémenté | Inline : `InMemoryWorkflowRunner` ; option `child_workflow.async_messenger` : dispatch `WorkflowRunMessage` + finalisation parent dans `WorkflowRunHandler` |
| ExecutionRuntime | Implémenté | await, drain, checkTimers |
| EventStoreInterface | Implémenté | Dbal, InMemory |
| ActivityTransportInterface | Implémenté | Messenger, Dbal, InMemory |
| ActivityExecutor | Implémenté | Registry |
| DurableBundle | Implémenté | DI, commande |
| Mode distribué complet | Non implémenté | Workflow non re-dispatché après activité (selon déploiement) |
| Temporal driver | Non implémenté | Opportunité future ([OST001](../ost/OST001-future-opportunities.md)) |

### Matrice parité Temporal ↔ Durable ([OST004](../ost/OST004-workflow-temporal-feature-parity.md))

| Fonctionnalité Temporal | État Durable | Notes |
|-------------------------|--------------|-------|
| [Side effects](https://docs.temporal.io/develop/php/side-effects) | **Supporté** | `SideEffectRecorded`, `sideEffect()` / helper |
| [Durable timers](https://docs.temporal.io/develop/php/timers) | **Supporté** | `delay()` / `timer()` + événements timer |
| [Child workflows](https://docs.temporal.io/develop/php/child-workflows) | **Partiel** | Types enregistrés + journal parent/enfant ; pas de parent close policy / stub typé |
| [Continue-as-new](https://docs.temporal.io/develop/php/continue-as-new) | **Partiel** | Nouveau `executionId` + dispatch Messenger ; pas de même id logique / run id |
| [Signals / Queries / Updates](https://docs.temporal.io/develop/php/message-passing) | **Partiel** | `waitSignal` / `waitUpdate` + append événements ; queries = `WorkflowQueryEvaluator` ; pas d’attributs handler / client riche |

Références
---

- [INDEX.md](../INDEX.md)
- [ADR004 - Ports et Adapters](../adr/ADR004-ports-and-adapters.md)
- [ADR005 - Messenger](../adr/ADR005-messenger-integration.md)
- [ADR010 - Parité Temporal, événements et replay](../adr/ADR010-temporal-parity-events-and-replay.md)
- [OST001 - Opportunités futures](../ost/OST001-future-opportunities.md)
- [OST004 - Parité fonctionnelle workflow / Temporal](../ost/OST004-workflow-temporal-feature-parity.md)
