<?php

declare(strict_types=1);

namespace Gplanchat\Durable\Event;

/**
 * Échec d’un workflow enfant (journal du **parent**).
 */
final readonly class ChildWorkflowFailed implements Event
{
    public function __construct(
        private string $parentExecutionId,
        private string $childExecutionId,
        private string $failureMessage,
        private int $failureCode = 0,
    ) {
    }

    public function executionId(): string
    {
        return $this->parentExecutionId;
    }

    public function childExecutionId(): string
    {
        return $this->childExecutionId;
    }

    public function failureMessage(): string
    {
        return $this->failureMessage;
    }

    public function failureCode(): int
    {
        return $this->failureCode;
    }

    public function payload(): array
    {
        return [
            'childExecutionId' => $this->childExecutionId,
            'failureMessage' => $this->failureMessage,
            'failureCode' => $this->failureCode,
        ];
    }
}
