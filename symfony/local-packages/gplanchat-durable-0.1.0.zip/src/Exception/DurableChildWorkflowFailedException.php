<?php

declare(strict_types=1);

namespace Gplanchat\Durable\Exception;

/**
 * Échec d’un workflow enfant observé par le parent (journal {@see \Gplanchat\Durable\Event\ChildWorkflowFailed}).
 */
final class DurableChildWorkflowFailedException extends \RuntimeException
{
    public function __construct(
        public readonly string $childExecutionId,
        string $message,
        int $code = 0,
        ?\Throwable $previous = null,
    ) {
        parent::__construct($message, $code, $previous);
    }
}
