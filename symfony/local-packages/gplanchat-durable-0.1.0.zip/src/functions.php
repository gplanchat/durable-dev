<?php

declare(strict_types=1);

namespace Gplanchat\Durable;

use Gplanchat\Durable\Awaitable\ActivityAwaitable;
use Gplanchat\Durable\Awaitable\AnyAwaitable;
use Gplanchat\Durable\Awaitable\Awaitable;
use Gplanchat\Durable\Awaitable\CancellingAnyAwaitable;

function await(Awaitable $awaitable, ExecutionContext $context, ExecutionRuntime $runtime): mixed
{
    return $runtime->await($awaitable, $context);
}

function async(mixed $value): Awaitable
{
    $deferred = new \Gplanchat\Durable\Awaitable\Deferred();
    $deferred->resolve($value);

    return $deferred->awaitable();
}

/**
 * @return array<int, mixed>
 */
function parallel(ExecutionContext $context, ExecutionRuntime $runtime, Awaitable ...$awaitables): array
{
    $results = [];
    foreach ($awaitables as $awaitable) {
        $results[] = await($awaitable, $context, $runtime);
    }

    return $results;
}

/** Alias for parallel. */
function all(ExecutionContext $context, ExecutionRuntime $runtime, Awaitable ...$awaitables): array
{
    return parallel($context, $runtime, ...$awaitables);
}

function any(ExecutionContext $context, ExecutionRuntime $runtime, Awaitable ...$awaitables): mixed
{
    $inner = new AnyAwaitable($awaitables);
    $composite = $inner;
    foreach ($awaitables as $a) {
        if ($a instanceof ActivityAwaitable) {
            $composite = new CancellingAnyAwaitable($context, $inner, $awaitables);
            break;
        }
    }

    return await($composite, $context, $runtime);
}

/** Alias for any. */
function race(ExecutionContext $context, ExecutionRuntime $runtime, Awaitable ...$awaitables): mixed
{
    return any($context, $runtime, ...$awaitables);
}

function delay(ExecutionContext $context, ExecutionRuntime $runtime, float $seconds): void
{
    await($context->delay($seconds), $context, $runtime);
}

/** Alias de {@see delay()} — alignement Temporal Durable Timers. */
function timer(ExecutionContext $context, ExecutionRuntime $runtime, float $seconds): void
{
    await($context->timer($seconds), $context, $runtime);
}

/**
 * @template T
 * @param \Closure(): T $closure
 *
 * @return T
 */
function sideEffect(ExecutionContext $context, ExecutionRuntime $runtime, \Closure $closure): mixed
{
    return await($context->sideEffect($closure), $context, $runtime);
}

/**
 * @return mixed
 */
function execute_child_workflow(ExecutionContext $context, ExecutionRuntime $runtime, string $childWorkflowType, array $input = [], ?ChildWorkflowOptions $options = null): mixed
{
    return await($context->executeChildWorkflow($childWorkflowType, $input, $options), $context, $runtime);
}

/** @return array<mixed> */
function wait_signal(ExecutionContext $context, ExecutionRuntime $runtime, string $signalName): array
{
    return await($context->waitSignal($signalName), $context, $runtime);
}

function wait_update(ExecutionContext $context, ExecutionRuntime $runtime, string $updateName): mixed
{
    return await($context->waitUpdate($updateName), $context, $runtime);
}
