<?php

declare(strict_types=1);

namespace Gplanchat\Durable\Bundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

final class DurableBundle extends Bundle
{
}
