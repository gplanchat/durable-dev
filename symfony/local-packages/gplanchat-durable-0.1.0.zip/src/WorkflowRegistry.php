<?php

declare(strict_types=1);

namespace Gplanchat\Durable;

/**
 * Registre des workflows par type.
 *
 * Les factories reçoivent le payload et retournent un callable(ExecutionContext, ExecutionRuntime): mixed.
 *
 * @see ADR009 Modèle distribué et re-dispatch
 */
final class WorkflowRegistry
{
    /** @var array<string, callable(array): callable> */
    private array $factories = [];

    public function register(string $workflowType, callable $factory): void
    {
        $this->factories[$workflowType] = $factory;
    }

    /**
     * @return callable(ExecutionContext, ExecutionRuntime): mixed
     */
    public function getHandler(string $workflowType, array $payload): callable
    {
        $factory = $this->factories[$workflowType] ?? null;
        if (null === $factory) {
            throw new \InvalidArgumentException(\sprintf('Unknown workflow type: %s', $workflowType));
        }

        return $factory($payload);
    }

    public function has(string $workflowType): bool
    {
        return isset($this->factories[$workflowType]);
    }
}
